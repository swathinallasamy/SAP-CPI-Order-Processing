
import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def body = message.getBody(String)
    def valid = true

    def orderId = body.find(/<orderId>(.*?)<\/orderId>/) {
        match, value -> value.trim()
    }

    def customerId = body.find(/<customerId>(.*?)<\/customerId>/) {
        match, value -> value.trim()
    }

    def quantity = body.find(/<quantity>(.*?)<\/quantity>/) {
        match, value -> value.trim()
    }

    if (!orderId) {
        body = body.replaceAll(/<orderId>.*?<\/orderId>|<orderId\s*\/>/,
                "<orderId>Invalid Order ID</orderId>")
        valid = false
    }

    if (!customerId) {
        body = body.replaceAll(/<customerId>.*?<\/customerId>|<customerId\s*\/>/,
                "<customerId>Invalid Customer ID</customerId>")
        valid = false
    }

    if (!quantity?.isInteger() || quantity.toInteger() <= 0) {
        body = body.replaceAll(/<quantity>.*?<\/quantity>|<quantity\s*\/>/,
                "<quantity>Invalid quantity</quantity>")
        valid = false
    }

    message.setBody(body.toString())
    message.setProperty("validationStatus", valid ? "VALID" : "FAILED")

    return message
}
